console.log("Dades carregades");

const personas = [
  {
    nombre: 'Juan',
    dni: '12345678',
    hobbies: ['leer', 'bailar'],
  },
  {
    nombre: 'María',
    dni: '87654321',
    hobbies: ['pintar', 'correr', 'viajar'],
  },
  {
    nombre: 'Pedro',
    dni: '98765432',
    hobbies: ['cocinar', 'ver películas'],
  },
  {
    nombre: 'Laura',
    dni: '54321678',
    hobbies: ['hacer deporte', 'viajar'],
  },
  {
    nombre: 'Carlos',
    dni: '87651234',
    hobbies: ['tocar la guitarra', 'hacer deporte'],
  },
];
