

const arrayPreguntesObj = [

    {
        enunciat    :"Quantes rodes té un cotxe?",
        opcio1      :"1 roda",
        opcio2      :"2 rodes",
        opcio3      :"3 rodes",
        opcio4      :"4 rodes",
        correcta    :"opcio4"
    },
    {
        enunciat    :"Quantes potes té un gall?",
        opcio1      :"1 pota",
        opcio2      :"2 potes",
        opcio3      :"3 potes",
        opcio4      :"4 potes",
        correcta    :"opcio2"
    },
    {
        enunciat    :"Quants metres fa el Tibidabo?",
        opcio1      :"232 metres",
        opcio2      :"456 metres",
        opcio3      :"512 metres",
        opcio4      :"689 metres",
        correcta    :"opcio3"
    },

];